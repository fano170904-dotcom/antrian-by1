# ANTRIAN BY1

## Jalankan demo
Buka `index.html` di browser. Mode demo menyimpan data di browser/perangkat yang sama.

## Aktifkan sinkronisasi real-time (Firebase)
1. Buat project di https://console.firebase.google.com/
2. Tambahkan Web App, salin konfigurasi Firebase.
3. Buat Realtime Database.
4. Aktifkan Authentication > Sign-in method > Email/Password, lalu buat akun admin di Authentication > Users.
5. Ganti nilai `firebaseConfig` di bagian CONFIG pada `index.html`.
6. Atur Realtime Database Rules menjadi:
   {
     "rules": {
       "queues": {
         ".read": true,
         ".write": "auth != null"
       }
     }
   }
   Aturan ini membuat antrean bisa dibaca publik, tetapi hanya pengguna yang login bisa mengubahnya.
7. Deploy folder ini ke Vercel sebagai project static (framework: Other; output directory: `.`).

Catatan: Jangan membagikan akun admin. Untuk penggunaan ramai/produksi, pertimbangkan validasi tambahan dan batasi siapa yang boleh menjadi admin.
